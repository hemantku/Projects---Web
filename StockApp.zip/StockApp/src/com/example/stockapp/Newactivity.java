package com.example.stockapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Newactivity extends Activity {

	String url = "";
    HashMap<String,String> urlmap = new HashMap<String,String>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_newactivity);
		
		ArrayList<String> newsList = new ArrayList<String>();
		
		Intent intent = getIntent();
		String jsonArray = intent.getStringExtra("array");
		System.out.println(jsonArray);
		try 
		{
			JSONObject jsontest = new JSONObject(jsonArray);
			System.out.println(jsontest);
			JSONArray item = jsontest.getJSONArray("Item");
			System.out.println(item);
			System.out.println(item.length());
			for(int i = 0; i < item.length(); i++)
			{	
				
				System.out.println(item.getJSONObject(i).getString("Title"));
				newsList.add(item.getJSONObject(i).getString("Title"));
		urlmap.put(item.getJSONObject(i).getString("Title"),item.getJSONObject(i).getString("Link"));
				System.out.println(item.getJSONObject(i).getString("Link"));
			
			}
			final ListView list = (ListView) findViewById(R.id.listView1);
			ArrayAdapter<String> adapter =
					new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, newsList);
		
			list.setAdapter(adapter);
			Toast.makeText(Newactivity.this,"Showing " + item.length() + " headlines", Toast.LENGTH_SHORT).show();
			list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView<?> parentAdapter, View view, int position,long id) {
				TextView clickedView = (TextView) view;
			    Toast.makeText(Newactivity.this, "Item with id ["+id+"] - Position ["+position+"] - Planet ["+clickedView.getText()+"]", Toast.LENGTH_SHORT).show();
			   url = urlmap.get(clickedView.getText());
			   System.out.println("Url is here:" + url);
			   registerForContextMenu(list);
			}
			});
			

			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
     public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo) 
	{
		
		super.onCreateContextMenu(menu, v, menuInfo);
		AdapterContextMenuInfo aInfo = (AdapterContextMenuInfo) menuInfo;
		int index = aInfo.position;
		System.out.println("Url is here:" + url);
		System.out.println("The position is:" + index + "id:" + aInfo.id);
		menu.setHeaderTitle("View News");
		menu.add(1, 1, 1, "News");
		menu.add(1, 2, 2, "Cancel");
	}
	@Override  
	public boolean onContextItemSelected(MenuItem item) {
		
		switch(item.getItemId()) {
		case 1:
			System.out.println("Url is here:" + url);
			Intent intent = new Intent(Intent.ACTION_VIEW, 
				     Uri.parse(url));
			startActivity(intent);
			 return true;
		case 2:
			return false;
		}
		return false;
		
		
		
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.newactivity, menu);
		return true;
	}

}
