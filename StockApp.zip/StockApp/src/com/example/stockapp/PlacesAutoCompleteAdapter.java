package com.example.stockapp;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.Filter;


public class PlacesAutoCompleteAdapter extends ArrayAdapter<String> implements Filterable {
    private ArrayList<String> resultList;
    //private static final String LOG_TAG = "ExampleApp";
    
    private static final String PLACES_API_BASE = "http://d.yimg.com/aq/autoc?query=";
    private static final String TYPE_AUTOCOMPLETE = "&callback=YAHOO.util.ScriptNodeDataSource.callbacks";
    //private static final String OUT_JSON = "/json";

    //private static final String API_KEY = "YOUR_API_KEY";

    public PlacesAutoCompleteAdapter(Context context, int textViewResourceId) {
        super(context, textViewResourceId);
    }

    @Override
    public int getCount() {
        return resultList.size();
    }

    @Override
    public String getItem(int index) {
        return resultList.get(index);
    }

    @Override
    public android.widget.Filter getFilter() {
        Filter filter = new Filter() {
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();
                if (constraint != null) {
                    // Retrieve the autocomplete results.
                	System.out.println("I am in Filter");
                    resultList = autocomplete(constraint.toString());

                    // Assign the data to the FilterResults
                    filterResults.values = resultList;
                    System.out.println("Result List:" + resultList);
;                    filterResults.count = resultList.size();
                }
                return filterResults;
            }

            private ArrayList<String> autocomplete(String input) {
				// TODO Auto-generated method stub
            	String remove = "YAHOO.util.ScriptNodeDataSource.callbacks({\"ResultSet\":";
            	String remove2 = "})";
            	ArrayList<String> resultList = null;
            	System.out.println("I am in autocomplete");
                HttpURLConnection conn = null;
                String jsonfinal = null;
                StringBuilder jsonResults = new StringBuilder();
                try {
                    StringBuilder sb = new StringBuilder(PLACES_API_BASE);
                    sb.append(URLEncoder.encode(input, "utf8"));
                    sb.append(TYPE_AUTOCOMPLETE);
                    System.out.println("String is :" + sb);
                    
                    URL url = new URL(sb.toString());
                    conn = (HttpURLConnection) url.openConnection();
                    InputStreamReader in = new InputStreamReader(conn.getInputStream());

                    // Load the results into a StringBuilder
                    int read;
                    char[] buff = new char[1024];
                    while ((read = in.read(buff)) != -1) {
                    	
                        jsonResults.append(buff, 0, read);
                    }
                    int i = jsonResults.indexOf(remove);
                    jsonResults.delete(i,i + remove.length());
                    int j = jsonResults.indexOf(remove2);
                    jsonResults.delete(j,j+remove2.length());
                    System.out.println("The Json is " + jsonResults);
                    jsonfinal = jsonResults.toString();
                } catch (MalformedURLException e) {
                    //Log.e(LOG_TAG, "L", e);
                	System.out.println("Error processing Places API URL");
                    return resultList;
                } catch (IOException e) {
                    //Log.e(LOG_TAG, "Error connecting to Places API", e);
                	System.out.println("Error connecting to Places API");
                    return resultList;
                } finally {
                    if (conn != null) {
                        conn.disconnect();
                    }
                }

                try {
                    // Create a JSON object hierarchy from the results
                	//System.out.println("The jsonObj is :" + jsonfinal);
                	//System.out.println("The json string is:" + jsonResults.toString());
                	//String test = jsonResults.toString();
                	//System.out.println("The test string is:" + test);
                    JSONObject jsonObj = new JSONObject(jsonfinal);
                    System.out.println("The jsonObj is :" + jsonObj);
                    //JSONObject resultset = jsonObj.getJSONObject("ResultSet");
                    JSONArray predsJsonArray = jsonObj.getJSONArray("Result");
                    System.out.println("The predsJsonArray" + predsJsonArray);
                    // Extract the Place descriptions from the results
                    resultList = new ArrayList<String>(predsJsonArray.length());
                    for (int i = 0; i < predsJsonArray.length(); i++) {
                    String Text = predsJsonArray.getJSONObject(i).getString("symbol") + ", " + predsJsonArray.getJSONObject(i).getString("name") +"(" + predsJsonArray.getJSONObject(i).getString("exchDisp") +")";
                    resultList.add(Text);
                       // System.out.println("The result is:" + resultList.get(object))
                    }
                    System.out.println();
                } catch (JSONException e) {
                    
                	System.out.println("Cannot process JSON results");
                }

                return resultList;
            	
				
			}

			@Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (results != null && results.count > 0) {
                    notifyDataSetChanged();
                }
                else {
                    notifyDataSetInvalidated();
                }
            }};
        return filter;
    }
}