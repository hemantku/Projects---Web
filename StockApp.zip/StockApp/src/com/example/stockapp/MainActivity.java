package com.example.stockapp;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.*;
import com.facebook.model.*;
import com.facebook.widget.WebDialog;
import com.facebook.widget.WebDialog.OnCompleteListener;


public class MainActivity extends Activity  {

	
	private Button searchBtn;
	private AutoCompleteTextView searchTxt;
	final Context context = this;
	private JSONObject jsonObject;
	String jsonresponse;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		try
		{
			searchBtn = (Button) findViewById(R.id.button1);
			searchTxt = (AutoCompleteTextView) findViewById(R.id.editText1);
			searchTxt.setAdapter(new PlacesAutoCompleteAdapter(this,R.layout.listitem));
			searchTxt.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
				String str = (String) listView.getItemAtPosition(position);
				String[] parts = str.split(",");
				searchTxt.setText(parts[0]);
				searchBtn.performClick();
				}
			});
			searchBtn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) 
				{
					String query = searchTxt.getText().toString();
					/* Handle empty input case */
					if (query == null || query.equals("")) 
					{
						 AlertDialog.Builder builder = new AlertDialog.Builder(context);
						 builder.setTitle("");
						 builder.setMessage("Please Enter Stock Symbol!");
						 builder.setNeutralButton("OK", new DialogInterface.OnClickListener() {
			                    public void onClick(DialogInterface dialog, int id) {
			                    	 
			                        dialog.cancel();
			                    }
						 }).show();
						 
						return;
					}
					String url;
					try 
					{
						url = "http://cs-server.usc.edu:17001/examples/servlet/StockSearch?symbol=" + URLEncoder.encode(query,"UTF-8");
						System.out.println("The URL to be sent to servlet is " + url);
						new AsyncTaskRunner().execute(url);
						System.out.println("This statement is also executed");
						
				    } catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				
				
			});
			
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();  
			/* System.out.println(e.getMessage()); */
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
   
	private class AsyncTaskRunner extends AsyncTask<String, String, String>
	{

	 @Override
		protected String doInBackground(String... arg0) 
		{
			// TODO Auto-generated method stub
			URL url = null;
			//String jsonresponse;
			try
			{
				System.out.println("Entering doInback function with arg0[0] = " + url);
				url = new URL(arg0[0]);
				System.out.println("We have got the URL now. Its " + url);
				
			}
			catch (MalformedURLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				jsonresponse = e1.getMessage();
			}
			try
			{
				System.out.println("URLConnection is being executed");
				InputStream urlinput = url.openStream();
				System.out.println("URL openStream function executed");
				InputStreamReader input=new InputStreamReader(urlinput);
				System.out.println("URL InputStreamReader made");
				BufferedReader buffer=new BufferedReader(input);
				System.out.println("BufferedReader made");
				String readtext;
				StringBuffer sbuffer = new StringBuffer();
				while((readtext = buffer.readLine()) != null) 
				{
					sbuffer.append(readtext);
				}
				jsonresponse =(String)sbuffer.toString();
				System.out.println("JSON Response is " + jsonresponse);
				buffer.close();
				return jsonresponse;
				
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				jsonresponse = e.getMessage();
			}
			return null;
		}
		@Override
		protected void onPostExecute(String result)
		{
			System.out.println("I am here");
			try
			{
			     jsonObject = new JSONObject(result);
				//System.out.println("The value is:" + jsonObject.getJSONObject("result").getJSONObject("Quote").getDouble("Change"));
				if(!jsonObject.getJSONObject("result").getJSONObject("Quote").has("Change") || jsonObject.getJSONObject("result").getJSONObject("Quote").getString("Change").length() == 0)
				{
					System.out.println("No Information found");
					AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
			    	alertDialog.setMessage("Stock Information Not Found!");
					alertDialog.setNeutralButton("OK", new DialogInterface.OnClickListener() {
		            public void onClick(DialogInterface dialog, int id) {
		                    	 
		                        dialog.cancel();
		                    }
					 }).show();
					
					return;
					
				}
				else
				{
					
					final JSONObject result1 = jsonObject.getJSONObject("result");
					JSONObject quote = result1.getJSONObject("Quote");
					TextView name = (TextView)findViewById(R.id.textView2);
					StringBuilder namestring = new StringBuilder();
					namestring.append(result1.getString("Name"));
					namestring.append("(");
					namestring.append(result1.getString("Symbol"));
					namestring.append(")");
					System.out.println("The string is:" + namestring);
					name.setText(namestring);
					
					
					TextView tradeprice = (TextView)findViewById(R.id.textView3);
					String stringdouble= Double.toString(quote.getDouble("LastTradePriceOnly"));
					tradeprice.setText(stringdouble);
					TextView price = (TextView)findViewById(R.id.textView4);
					//price.setTextColor(Color.GREEN);
					ImageView imgView2 = (ImageView) findViewById(R.id.imageView2);
					if(quote.getString("ChangeType").equals("-"))
					{
						System.out.println("I am here - 2");
						price.setTextColor(Color.RED);
						imgView2.setImageResource(R.drawable.down_r);
						
						
					}
					else if(quote.getString("ChangeType").equals("+"))
					{
						price.setTextColor(Color.GREEN);
						imgView2.setImageResource(R.drawable.up_g);
					}
					
					StringBuilder pricestring = new StringBuilder();
					pricestring.append(Double.toString(quote.getDouble("Change")));
					pricestring.append("(");
					pricestring.append(quote.getString("ChangeinPercent"));
					pricestring.append(")");
					price.setText(pricestring);
					
					TextView prevclose1 = (TextView)findViewById(R.id.textView5);
					TextView prevclose2 = (TextView)findViewById(R.id.textView6);
					prevclose1.setText("Prev Close");
					String stringclose = Double.toString(quote.getDouble("PreviousClose"));
					prevclose2.setText(stringclose);
					
					TextView open1 = (TextView)findViewById(R.id.textView7);
					TextView open2 = (TextView)findViewById(R.id.textView8);
					open1.setText("Open");
					String stringopen = Double.toString(quote.getDouble("Open"));
					open2.setText(stringopen);
					
					TextView bid1 = (TextView)findViewById(R.id.textView9);
					TextView bid2 = (TextView)findViewById(R.id.textView10);
					bid1.setText("Bid");
					String stringbid = Double.toString(quote.getDouble("Bid"));
					bid2.setText(stringbid);
					
					TextView ask1 = (TextView)findViewById(R.id.textView11);
					TextView ask2 = (TextView)findViewById(R.id.textView12);
					ask1.setText("Ask");
					String stringask = Double.toString(quote.getDouble("Ask"));
					ask2.setText(stringask);
					
					TextView target1 = (TextView)findViewById(R.id.textView13);
					TextView target2 = (TextView)findViewById(R.id.textView14);
					target1.setText("1st Yr Target");
					String stringtarget = Double.toString(quote.getDouble("OneyrTargetPrice"));
					target2.setText(stringtarget);
					
					TextView range1 = (TextView)findViewById(R.id.textView15);
					TextView range2 = (TextView)findViewById(R.id.textView16);
					range1.setText("Day's Range");
					String high = Double.toString(quote.getDouble("DaysHighs"));
					String low = Double.toString(quote.getDouble("DaysLow"));
					String range = high + '-' + low;
					range2.setText(range);
					
					TextView wrange1 = (TextView)findViewById(R.id.textView17);
					TextView wrange2 = (TextView)findViewById(R.id.textView18);
					wrange1.setText("52 wk Range");
					String yearlow = "";
					String yearhigh = "";
					if(!quote.get("YearLow").equals(""))
							yearlow = Double.toString(quote.getDouble("YearLow"));
					if(!quote.get("YearHigh").equals(""))
					        yearhigh = Double.toString(quote.getDouble("YearHigh"));
					
					String wrange = yearhigh + '-' + yearlow;
					wrange2.setText(wrange);
					
					String volume = "";
					TextView vol1 = (TextView)findViewById(R.id.textView19);
					TextView vol2 = (TextView)findViewById(R.id.textView20);
					vol1.setText("Volume");
					if(!quote.get("Volume").equals(""))
					 volume = Double.toString(quote.getDouble("Volume"));
					vol2.setText(volume);
					
					String avolume = "";
					TextView avol1 = (TextView)findViewById(R.id.textView21);
					TextView avol2 = (TextView)findViewById(R.id.textView22);
					avol1.setText("Avg Vol(3m)");
					
					if(!quote.get("AverageDailyVolume").equals(""))
					avolume = quote.getString("AverageDailyVolume");
					
					avol2.setText(avolume);
					String mcap ="";
					TextView mcap1 = (TextView)findViewById(R.id.textView23);
					TextView mcap2 = (TextView)findViewById(R.id.textView24);
					mcap1.setText("Market Cap");
					
					if(!quote.get("MarketCapitalization").equals("")) 
					mcap = quote.getString("MarketCapitalization");
					
					mcap2.setText(mcap);
					TableLayout vtable = (TableLayout) findViewById(R.id.tableLayout1);
					vtable.setVisibility(0);
					name.setVisibility(0);
					tradeprice.setVisibility(0);
					price.setVisibility(0);
					imgView2.setVisibility(0);
					Button headlines = (Button) findViewById(R.id.button2);
					
					JSONObject news =  result1.getJSONObject("News");
					JSONArray item = news.getJSONArray("Item");
					if(item.getJSONObject(0).getString("Title") != "Yahoo! Finance: RSS feed not found" )
					{
				
					headlines.setVisibility(0);
					headlines.setOnClickListener(new OnClickListener() {
					public void onClick(View arg0) {
						JSONObject news = null;
							try {
								 news = result1.getJSONObject("News");
								 
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						    Intent intent = new Intent(context, Newactivity.class);
						    intent.putExtra("array",news.toString());
			                startActivity(intent);   
			 
						}});
					}
					
					Button facebook_click = (Button) findViewById(R.id.button3);
					facebook_click.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) 
						{
							fbLogin(1);
						
						}
					});
					facebook_click.setVisibility(0);
						
				
					
					String imageurl = result1.getString("StockChartImageURL");
					new GetImage().execute(imageurl);
					
					
					
					
				}
				
			}
		    catch (JSONException e) 
		    {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			

		}
		private class GetImage extends AsyncTask<String, Void, Bitmap>
		{
			ImageView imgView = (ImageView) findViewById(R.id.imageView1);
			
			@Override
			protected Bitmap doInBackground(String... urls)
			{
				Bitmap map = null;
	            for (String url : urls) 
	            {
	            	map = downloadImage(url);
		        }
		        return map;
			}
			 private Bitmap downloadImage(String url) 
		     {
		            Bitmap bitmap = null;
		            InputStream stream = null;
		            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
		            bmOptions.inSampleSize = 1;
		 
		            try
		            {
		                /*stream = getHttpConnection(url);*/
		            	URL imageURL = new URL(url);
		            	InputStream urlStream = imageURL.openStream();
		                bitmap = BitmapFactory.decodeStream(urlStream, null, bmOptions);
		                urlStream.close();
		            } catch (IOException e1) {
		                e1.printStackTrace();
		            }
		            return bitmap;
		     }	
			 @Override
		     protected void onPostExecute(Bitmap result) 
		     {
				 imgView.setImageBitmap(result);
				 imgView.setVisibility(0);
			
		     }		 
		}
		public void fbLogin(final int token)
		{
			 Session.openActiveSession(this, true, new Session.StatusCallback() 
			 {
				   @SuppressWarnings("deprecation")
				   @Override
				   public void call(Session session, SessionState state, Exception exception) 
				   {
					   if (session.isOpened()) 
				        {
						   Request.executeMeRequestAsync(session, new Request.GraphUserCallback()
						   {
							   @Override
					            public void onCompleted(GraphUser user, Response response) 
					            {
								   if (user != null) 
						              {
						            	  System.out.println("Reached inside fbLogin function");
						            	  publishFeedDialog(token);
						              }	
								   
								   
					            }
						   });
						   
				        }
				   }
				 
			 });
			
		}
		private void publishFeedDialog(int tokenPassed) {
			System.out.println("Reached inside publishFeedDialog function");
			Bundle params = new Bundle();
			try {
				
				String name = jsonObject.getJSONObject("result").getString("Name");
				String symbol = jsonObject.getJSONObject("result").getString("Symbol");
				String url = jsonObject.getJSONObject("result").getString("StockChartImageURL");
				String titleurl = "http://finance.yahoo.com/q?s=" + symbol;
				Double ltp = jsonObject.getJSONObject("result").getJSONObject("Quote").getDouble("LastTradePriceOnly");
				Double chg = jsonObject.getJSONObject("result").getJSONObject("Quote").getDouble("Change");
				String chgp = jsonObject.getJSONObject("result").getJSONObject("Quote").getString("ChangeinPercent");
				
				String textinfo = "Last Trade Price is:" + ltp + ",Change is:" + chg + "(" + chgp + ")";
				String stock = "Stock Information of" + name + "(" + symbol + ")";
				
				params.putString("app_id", "659968994040512");
				params.putString("name", name);
				params.putString("caption",stock);
				params.putString("description", textinfo);
				params.putString("link",titleurl);
				params.putString("picture",url);
				
				 WebDialog feedDialog = (
					        new WebDialog.FeedDialogBuilder(MainActivity.this,
					            Session.getActiveSession(),
					            params))
					        .setOnCompleteListener(new OnCompleteListener() {
				
					            @Override
					            public void onComplete(Bundle values,
					                FacebookException error) {
					                if (error == null) {
					                    // When the story is posted, echo the success
					                    // and the post Id.
					                    final String postId = values.getString("post_id");
					                    if (postId != null) {
					                        Toast.makeText(MainActivity.this,
					                            "Posted story, id: "+postId,
					                            Toast.LENGTH_SHORT).show();
					                    } else {
					                        // User clicked the Cancel button
					                        Toast.makeText(MainActivity.this.getApplicationContext(), 
					                            "Publish cancelled", 
					                            Toast.LENGTH_SHORT).show();
					                    }
					                } else if (error instanceof FacebookOperationCanceledException) {
					                    // User clicked the "x" button
					                    Toast.makeText(MainActivity.this.getApplicationContext(), 
					                        "Publish cancelled", 
					                        Toast.LENGTH_SHORT).show();
					                } else {
					                    // Generic, ex: network error
					                    Toast.makeText(MainActivity.this.getApplicationContext(), 
					                        "Error posting story", 
					                        Toast.LENGTH_SHORT).show();
					                }
					            }
				
					        })
					        .build();
					    feedDialog.show();
						 
						 
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
		public void onActivityResult(int requestCode, int resultCode, Intent data) 
		{
			super.onActivityResult(requestCode, resultCode, data);
		    Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
		}
	
}
	


